# n8n workflow: SmartMirror-Vox intent router

The Flask app POSTs JSON to `N8N_WEBHOOK_URL`:
```json
{"text":"What is machine learning?","language":"en","source":"smartmirror-vox"}
```

## Build the workflow
1. Add a **Webhook** node.
   - Method: `POST`
   - Path: `smartmirror-vox`
   - Response mode: `Using Respond to Webhook node` (or use the Webhook node's response option if your n8n version supports it).
2. Add an **Edit Fields (Set)** node or **Code** node to normalize fields.
3. Add a **Switch** node using `{{$json.body.text || $json.text}}` (expression shape may differ depending on the Webhook node/version). Create routes for:
   - music playback
   - weather
   - outfit analysis
   - general question
4. For general questions, add an HTTP Request node to Groq's OpenAI-compatible endpoint:
   - POST `https://api.groq.com/openai/v1/chat/completions`
   - Header `Authorization: Bearer YOUR_GROQ_API_KEY`
   - Header `Content-Type: application/json`
   - JSON body:
```json
{
  "model": "llama-3.3-70b-versatile",
  "messages": [
    {"role":"system","content":"You are SmartMirror-Vox. Reply briefly in the user's requested language."},
    {"role":"user","content":"={{$json.body.text || $json.text}}"}
  ],
  "temperature": 0.4
}
```
5. Add **Respond to Webhook** and return a JSON object such as:
```json
{"answer":"={{$json.choices[0].message.content}}"}
```
Adapt expressions to the exact node output in your installed n8n version.
6. Activate the workflow and copy its **Production URL** into `.env`:
   `N8N_WEBHOOK_URL=https://YOUR-N8N-HOST/webhook/smartmirror-vox`

## Security
- Store provider credentials in n8n Credentials or environment variables, not in workflow text.
- Protect the webhook with authentication if exposed publicly.
- Do not expose a development webhook or n8n editor to the public internet without access controls.
