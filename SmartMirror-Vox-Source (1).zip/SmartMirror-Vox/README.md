# SmartMirror-Vox — Voice-Augmented Magic Mirror

A runnable laptop prototype based on the uploaded Phase-2 report. It follows the report's architecture:
- Frontend: HTML, CSS, JavaScript
- Backend: Python Flask
- Automation: optional n8n webhook
- AI: Groq for conversational Q&A; Google Gemini for outfit image analysis
- Speech: browser SpeechRecognition and SpeechSynthesis
- Weather: Open-Meteo fallback (no API key) or OpenWeather
- News: RSS feed parsing
- Music: browser-local audio file player
- Languages: English, Kannada, Telugu, Hindi, Tamil, Malayalam, Marathi, Bengali

## Important feature status
- **Working locally:** dashboard, clock/date, browser speech recognition where supported, speech playback, weather, RSS headlines, local music playback, API health check.
- **Requires API key:** AI question-answering (Groq); outfit image analysis (Gemini).
- **Optional:** n8n intent workflow, OpenWeather key.
- **Hairstyle generation:** this starter creates a generation prompt only. Real image output needs a selected image-generation provider and its API integration; no image is falsely represented as generated.
- **Eight-language support:** browser STT/TTS availability varies by OS/browser and language. The UI passes locale hints; this does not guarantee equivalent recognition quality on every machine.

## Requirements
- Windows 10/11, macOS or Linux
- Python 3.10+
- Current Chrome or Microsoft Edge recommended for browser speech recognition
- Internet connection for APIs, fonts, weather, and RSS

## Windows setup
1. Extract the project ZIP.
2. Install Python 3.10 or newer from python.org. During setup, enable **Add Python to PATH**.
3. Open the project folder in File Explorer. Click the address bar, type `cmd`, and press Enter.
4. Create a virtual environment:
   ```bat
   py -m venv .venv
   .venv\Scripts\activate
   ```
5. Install dependencies:
   ```bat
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```
6. Copy `env.example` to `.env`:
   ```bat
   copy env.example .env
   ```
7. Edit `.env` in Notepad. Add your API keys if you want AI Q&A or outfit analysis. Keep `.env` private and do not upload it to GitHub.
8. Start the app:
   ```bat
   python app.py
   ```
9. Open `http://127.0.0.1:5000` in Chrome or Edge.
10. Allow microphone access when prompted. Speech recognition generally requires localhost or HTTPS.

## API keys / external services
1. **Groq** — AI Q&A: create an API key in the Groq developer console and set `GROQ_API_KEY`.
2. **Google Gemini API** — outfit image analysis: obtain a key from Google AI Studio and set `GEMINI_API_KEY`.
3. **n8n** — optional automation: run n8n locally or use a hosted instance, create the webhook described in `n8n/README.md`, then set `N8N_WEBHOOK_URL`.
4. **OpenWeather** — optional alternative weather provider. Open-Meteo works as a no-key fallback.
5. **News RSS** — BBC World RSS is the default; customize `NEWS_RSS_URL` if needed.
6. **Hairstyle image generation** — requires a provider that supports image editing/generation. Add its API and upload/reference-image flow before treating the feature as complete.

Provider pricing, rate limits, regional availability and terms can change; check each provider's current terms before use.

## API routes
- `GET /api/health`
- `GET /api/config`
- `GET /api/weather`
- `GET /api/news`
- `POST /api/assistant` JSON: `{"text":"Hello","language":"en"}`
- `POST /api/analyze-outfit` multipart form: `image` plus optional `language`
- `POST /api/hairstyle` JSON: `{"style":"short textured crop","notes":"..."}`

## Voice command examples
- “What is the weather?”
- “Explain artificial intelligence.”
- “Play music”
- “Pause music”

Weather and music shortcuts are handled locally. Other questions go to n8n if configured, otherwise Groq.

## Privacy and safety
- Outfit images are processed by Gemini and deleted from the local upload folder after the request completes.
- Do not upload private images unless you are comfortable sending them to the configured provider.
- Never put API keys in JavaScript or HTML. Keys belong in `.env` or provider credential storage.
- Do not expose Flask's debug server to the public internet. Set `FLASK_DEBUG=false` for demonstrations on a trusted local network; use a production WSGI server for deployment.
- Camera access is not automatically activated; outfit analysis uses a user-selected image in this starter.

## Troubleshooting
- `GROQ_API_KEY is not configured`: add key to `.env`, restart Flask.
- `GEMINI_API_KEY is not configured`: add key to `.env`, restart Flask.
- Microphone button unavailable: use recent Chrome/Edge and check microphone permission.
- Weather unavailable: check internet and city spelling in `WEATHER_CITY`.
- No news headlines: check internet or change `NEWS_RSS_URL`.
- Port in use: change `PORT=5001` in `.env` and open that port locally.

## Suggested next steps for the physical mirror
1. Test all features in laptop browser first.
2. Choose a display, two-way mirror acrylic/glass, webcam, microphone, and speakers.
3. Run the dashboard full-screen on the computer connected to the display.
4. Keep the webcam off unless the user explicitly triggers a camera feature.
5. Add startup-on-boot and device-specific power management only after local testing.

## Mirror reflection and Hey Jarvis (updated)

- Open the dashboard in Chrome or Edge and click **Enable mirror camera**. Approve camera access to show a locally mirrored webcam preview. Video is not uploaded by this feature. The camera stays off until enabled and can be turned off with the button.
- Click **Enable Hey Jarvis** once and approve microphone access. Say **“Hey Jarvis”**, then ask a question; you can also say “Hey Jarvis, what is the weather?” in one utterance. The assistant speaks its reply and attempts to resume wake-word listening afterward.
- Weather refreshes every 10 minutes and news every 15 minutes while the page remains open; the clock/date update every second.
- Wake-word support uses the browser's Web Speech Recognition API, not a dedicated offline wake-word engine. It depends on browser support, internet/service availability, the selected speech language, microphone permissions, and whether the browser keeps the page active. For dependable always-on use, a native app or local wake-word engine is needed.
- A real mirror-like display requires a camera/webcam or a two-way mirror display with a screen behind it. This web preview simulates the reflection by horizontally flipping the webcam feed.
