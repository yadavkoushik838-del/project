import os
import json
import uuid
import mimetypes
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import quote

import requests
from flask import Flask, jsonify, render_template, request, send_from_directory
from dotenv import load_dotenv
from werkzeug.utils import secure_filename

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "static" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = str(UPLOAD_DIR)
app.config["JSON_SORT_KEYS"] = False

LANGUAGES = {
    "en": {"name": "English", "stt": "en-US", "tts": "en-US"},
    "kn": {"name": "ಕನ್ನಡ", "stt": "kn-IN", "tts": "kn-IN"},
    "te": {"name": "తెలుగు", "stt": "te-IN", "tts": "te-IN"},
    "hi": {"name": "हिन्दी", "stt": "hi-IN", "tts": "hi-IN"},
    "ta": {"name": "தமிழ்", "stt": "ta-IN", "tts": "ta-IN"},
    "ml": {"name": "മലയാളം", "stt": "ml-IN", "tts": "ml-IN"},
    "mr": {"name": "मराठी", "stt": "mr-IN", "tts": "mr-IN"},
    "bn": {"name": "বাংলা", "stt": "bn-IN", "tts": "bn-IN"},
}
ALLOWED_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}

def env(name, default=""):
    return os.getenv(name, default).strip()

def safe_json_response(data, status=200):
    return jsonify(data), status

def call_n8n(text, language):
    url = env("N8N_WEBHOOK_URL")
    if not url:
        return None
    try:
        r = requests.post(url, json={"text": text, "language": language, "source": "smartmirror-vox"}, timeout=30)
        r.raise_for_status()
        payload = r.json()
        if isinstance(payload, list) and payload:
            payload = payload[0]
        if isinstance(payload, dict):
            # Accept common n8n response shapes.
            return payload.get("answer") or payload.get("text") or payload.get("response") or payload
    except Exception as exc:
        app.logger.warning("n8n call failed: %s", exc)
    return None

def call_groq(prompt, system_prompt=None):
    api_key = env("GROQ_API_KEY")
    if not api_key:
        return None, "GROQ_API_KEY is not configured. Add it to .env to enable AI answers."
    model = env("GROQ_MODEL", "llama-3.3-70b-versatile")
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})
    try:
        r = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={"model": model, "messages": messages, "temperature": 0.5},
            timeout=45,
        )
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"], None
    except requests.RequestException as exc:
        app.logger.exception("Groq request failed")
        return None, f"AI service request failed: {exc}"

def call_gemini(prompt):
    api_key = env("GEMINI_API_KEY")
    if not api_key:
        return None, "GEMINI_API_KEY is not configured. Add it to .env to enable image analysis/generation."
    model = env("GEMINI_MODEL", "gemini-2.5-flash")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={quote(api_key)}"
    try:
        r = requests.post(url, json={"contents": [{"parts": [{"text": prompt}]}]}, timeout=60)
        r.raise_for_status()
        data = r.json()
        parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
        return "\n".join(p.get("text", "") for p in parts if p.get("text")), None
    except requests.RequestException as exc:
        app.logger.exception("Gemini request failed")
        return None, f"Gemini request failed: {exc}"

def get_weather():
    city = env("WEATHER_CITY", "Bengaluru")
    api_key = env("OPENWEATHER_API_KEY")
    if api_key:
        try:
            r = requests.get("https://api.openweathermap.org/data/2.5/weather",
                             params={"q": city, "appid": api_key, "units": "metric"}, timeout=12)
            r.raise_for_status()
            d = r.json()
            return {"city": city, "temp": round(d["main"]["temp"]), "description": d["weather"][0]["description"].title(),
                    "humidity": d["main"]["humidity"], "wind": round(d["wind"].get("speed", 0), 1), "source": "OpenWeather"}
        except Exception as exc:
            app.logger.warning("Weather API failed: %s", exc)
    # Open-Meteo fallback: no API key, geocoding for configured city.
    try:
        g = requests.get("https://geocoding-api.open-meteo.com/v1/search", params={"name": city, "count": 1, "language": "en", "format": "json"}, timeout=10)
        g.raise_for_status()
        results = g.json().get("results", [])
        if results:
            loc = results[0]
            w = requests.get("https://api.open-meteo.com/v1/forecast",
                             params={"latitude": loc["latitude"], "longitude": loc["longitude"],
                                     "current": "temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code",
                                     "timezone": "auto"}, timeout=10)
            w.raise_for_status()
            c = w.json().get("current", {})
            codes = {0:"Clear",1:"Mainly clear",2:"Partly cloudy",3:"Overcast",45:"Fog",48:"Rime fog",
                     51:"Light drizzle",53:"Drizzle",55:"Dense drizzle",61:"Light rain",63:"Rain",65:"Heavy rain",
                     71:"Light snow",73:"Snow",75:"Heavy snow",80:"Rain showers",81:"Rain showers",82:"Heavy showers",
                     95:"Thunderstorm",96:"Thunderstorm with hail",99:"Thunderstorm with hail"}
            return {"city": loc.get("name", city), "temp": round(c.get("temperature_2m", 0)),
                    "description": codes.get(c.get("weather_code"), "Current conditions"),
                    "humidity": c.get("relative_humidity_2m"), "wind": c.get("wind_speed_10m"), "source": "Open-Meteo"}
    except Exception as exc:
        app.logger.warning("Open-Meteo failed: %s", exc)
    return {"city": city, "temp": None, "description": "Weather unavailable", "humidity": None, "wind": None, "source": "offline"}

def get_news():
    # RSS-to-JSON via a public feed parser service is optional. RSS endpoint can be customized.
    rss_url = env("NEWS_RSS_URL", "https://feeds.bbci.co.uk/news/world/rss.xml")
    try:
        import feedparser
        feed = feedparser.parse(rss_url)
        items = []
        for entry in feed.entries[:6]:
            items.append({"title": entry.get("title", "News item"), "link": entry.get("link", "#"),
                          "published": entry.get("published", "")})
        return {"items": items, "source": rss_url}
    except Exception as exc:
        app.logger.warning("News RSS failed: %s", exc)
        return {"items": [], "source": rss_url, "error": "Could not load news. Check your internet connection."}

@app.get("/")
def index():
    return render_template("index.html", languages=LANGUAGES)

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "app": "SmartMirror-Vox", "time": datetime.now(timezone.utc).isoformat(),
                    "configured": {"groq": bool(env("GROQ_API_KEY")), "gemini": bool(env("GEMINI_API_KEY")),
                                   "n8n": bool(env("N8N_WEBHOOK_URL")), "openweather": bool(env("OPENWEATHER_API_KEY"))}})

@app.get("/api/weather")
def weather():
    return jsonify(get_weather())

@app.get("/api/news")
def news():
    return jsonify(get_news())

@app.post("/api/assistant")
def assistant():
    data = request.get_json(silent=True) or {}
    text = str(data.get("text", "")).strip()
    language = data.get("language", "en")
    if not text:
        return safe_json_response({"error": "Please provide a voice command or question."}, 400)
    if language not in LANGUAGES:
        language = "en"

    # n8n can classify intent and return an answer. If not configured or it fails, use Groq.
    n8n_result = call_n8n(text, language)
    if isinstance(n8n_result, str) and n8n_result:
        return jsonify({"answer": n8n_result, "source": "n8n", "language": language})
    system = (
        "You are SmartMirror-Vox, a concise, helpful voice assistant in a smart mirror. "
        f"Respond in {LANGUAGES[language]['name']}. Keep answers suitable for being spoken aloud. "
        "Do not claim to have performed actions you did not perform."
    )
    answer, error = call_groq(text, system)
    if answer:
        return jsonify({"answer": answer, "source": "Groq", "language": language})
    # Working fallback for setup/testing before API keys are added.
    fallback = f"I heard: {text}. Add GROQ_API_KEY or configure N8N_WEBHOOK_URL in .env to enable AI answers."
    return jsonify({"answer": fallback, "source": "local-fallback", "warning": error, "language": language})

@app.post("/api/analyze-outfit")
def analyze_outfit():
    image = request.files.get("image")
    language = request.form.get("language", "en")
    if not image or not image.filename:
        return safe_json_response({"error": "Choose an image first."}, 400)
    ext = Path(secure_filename(image.filename)).suffix.lower()
    if ext not in ALLOWED_IMAGE_EXTS:
        return safe_json_response({"error": "Use PNG, JPG, JPEG or WEBP images."}, 400)
    # Save a short-lived working copy so the project can display it. Avoid retaining user images by default.
    filename = f"{uuid.uuid4().hex}{ext}"
    path = UPLOAD_DIR / filename
    image.save(path)
    try:
        # Gemini multimodal image input via inline base64.
        api_key = env("GEMINI_API_KEY")
        if not api_key:
            return safe_json_response({"error": "Set GEMINI_API_KEY in .env to enable vision-based outfit analysis."}, 503)
        import base64
        mime = mimetypes.guess_type(path.name)[0] or "image/jpeg"
        encoded = base64.b64encode(path.read_bytes()).decode("ascii")
        model = env("GEMINI_MODEL", "gemini-2.5-flash")
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={quote(api_key)}"
        prompt = (
            f"Analyze the clothing and visible color coordination in this image. Respond in {LANGUAGES.get(language, LANGUAGES['en'])['name']}. "
            "Be respectful and practical. Comment only on visible clothing, color combinations, formality, and optional styling suggestions. "
            "Do not infer sensitive traits, body measurements, health, or identity. Do not rate the person's body or attractiveness. "
            "Give concise bullets: outfit summary, color coordination, occasion fit, and 2 optional styling ideas."
        )
        payload = {"contents": [{"parts": [{"text": prompt}, {"inline_data": {"mime_type": mime, "data": encoded}}]}]}
        r = requests.post(url, json=payload, timeout=60)
        r.raise_for_status()
        data = r.json()
        parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
        answer = "\n".join(p.get("text", "") for p in parts if p.get("text"))
        if not answer:
            answer = "No analysis text was returned. Try another image."
        return jsonify({"answer": answer, "source": "Gemini Vision"})
    except Exception as exc:
        app.logger.exception("Outfit analysis failed")
        return safe_json_response({"error": f"Image analysis failed: {exc}"}, 502)
    finally:
        try:
            path.unlink(missing_ok=True)
        except Exception:
            pass

@app.post("/api/hairstyle")
def hairstyle():
    # This endpoint creates a hairstyle prompt and returns a ready-to-copy prompt.
    # Actual image generation depends on an image model/provider and is intentionally not faked.
    data = request.get_json(silent=True) or {}
    style = str(data.get("style", "natural layered hairstyle")).strip()[:120]
    notes = str(data.get("notes", "")).strip()[:300]
    prompt = (
        "Create a photorealistic hairstyle preview using the user's own uploaded portrait as reference. "
        f"Requested hairstyle: {style}. Additional preferences: {notes or 'keep the original face, expression, lighting and background unchanged'}. "
        "Change only the hair; preserve identity and facial features; no beauty retouching."
    )
    return jsonify({
        "status": "prompt_ready",
        "prompt": prompt,
        "message": "For actual image generation, connect an image-generation provider and implement its API in this endpoint. This starter does not pretend an image was generated."
    })

@app.get("/api/config")
def config():
    return jsonify({"languages": LANGUAGES, "weather_city": env("WEATHER_CITY", "Bengaluru"),
                    "music_url": env("MUSIC_STREAM_URL", "")})

@app.get("/music/<path:filename>")
def music_file(filename):
    return send_from_directory(BASE_DIR / "music", filename)

@app.errorhandler(413)
def too_large(_error):
    return jsonify({"error": "File is too large. Maximum upload size is 12 MB."}), 413

if __name__ == "__main__":
    app.run(host=env("HOST", "127.0.0.1"), port=int(env("PORT", "5000")), debug=env("FLASK_DEBUG", "true").lower() == "true")
