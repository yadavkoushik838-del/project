const $ = (id) => document.getElementById(id);
const langSelect = $("language");
let lastAnswer = "";
let recognition = null;
let currentObjectUrl = null;
let wakeEnabled = false;
let awaitingCommand = false;
let voiceCommandInProgress = false;
let cameraStream = null;

function updateClock() {
  const now = new Date();
  $("clock").textContent = now.toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"});
  $("date").textContent = now.toLocaleDateString([], {weekday:"long", year:"numeric", month:"long", day:"numeric"});
}
updateClock(); setInterval(updateClock, 1000);

function setTranscript(text) { $("transcript").textContent = text; }
function setStatus(text) { $("connection").textContent = text.toUpperCase(); }

async function loadWeather() {
  try {
    const r = await fetch("/api/weather"); const w = await r.json();
    $("weather-city").textContent = w.city || "Weather";
    $("temperature").textContent = w.temp == null ? "--°" : `${w.temp}°C`;
    $("weather-description").textContent = w.description || "Unavailable";
    $("weather-icon").textContent = /rain|drizzle|storm/i.test(w.description || "") ? "☂" : /cloud|overcast|fog/i.test(w.description || "") ? "☁" : "☼";
  } catch { $("weather-description").textContent = "Weather unavailable"; }
}
async function loadNews() {
  $("newsList").innerHTML = '<p class="muted">Loading headlines…</p>';
  try {
    const r = await fetch("/api/news"); const data = await r.json();
    if (!data.items || !data.items.length) throw new Error(data.error || "No headlines available.");
    $("newsList").innerHTML = data.items.map(item => {
      const a = document.createElement("a"); a.className = "news-item"; a.href = item.link || "#"; a.target = "_blank"; a.rel = "noopener noreferrer";
      a.textContent = item.title;
      const small = document.createElement("small"); small.textContent = item.published || "LATEST HEADLINE"; a.appendChild(small);
      return a.outerHTML;
    }).join("");
  } catch (e) { $("newsList").innerHTML = `<p class="muted">${escapeHtml(e.message || "News unavailable")}</p>`; }
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

function speak(text) {
  if (!("speechSynthesis" in window)) { setTranscript("Speech playback is not supported by this browser."); return; }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  const option = window.SM_LANGUAGES[langSelect.value] || window.SM_LANGUAGES.en;
  utterance.lang = option.tts || option.stt || "en-US";
  utterance.onend = () => { if (wakeEnabled) startWakeRecognition(); };
  window.speechSynthesis.speak(utterance);
}
async function sendCommand(raw) {
  const text = (raw || $("command").value).trim();
  if (!text) return;
  $("command").value = "";
  setStatus("processing");
  setTranscript(`You: ${text}\nSmartMirror-Vox is thinking…`);
  // Local intent shortcuts make basic mirror actions usable without API keys.
  const lower = text.toLowerCase();
  if (/\b(play music|start music)\b/.test(lower)) { $("audioPlayer").play().catch(()=>{}); lastAnswer = "Playing music if an audio source is loaded."; setTranscript(`You: ${text}\n${lastAnswer}`); setStatus("ready"); maybeSpeakAnswer(lastAnswer); return; }
  if (/\b(pause music|stop music)\b/.test(lower)) { $("audioPlayer").pause(); lastAnswer = "Music paused."; setTranscript(`You: ${text}\n${lastAnswer}`); setStatus("ready"); maybeSpeakAnswer(lastAnswer); return; }
  if (/\b(what('?s| is) the weather|weather today)\b/.test(lower)) {
    await loadWeather(); lastAnswer = `${$("weather-city").textContent}: ${$("temperature").textContent}, ${$("weather-description").textContent}.`;
    setTranscript(`You: ${text}\n${lastAnswer}`); setStatus("ready"); maybeSpeakAnswer(lastAnswer); return;
  }
  try {
    const r = await fetch("/api/assistant", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({text, language:langSelect.value})});
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Assistant request failed");
    lastAnswer = data.answer || "I couldn't create an answer.";
    setTranscript(`You: ${text}\nSmartMirror-Vox: ${lastAnswer}${data.warning ? "\n\nSetup note: " + data.warning : ""}`);
    maybeSpeakAnswer(lastAnswer);
  } catch (e) { lastAnswer = e.message; setTranscript(`Error: ${e.message}`); }
  finally { setStatus("ready"); }
}
$("sendBtn").addEventListener("click", () => sendCommand());
$("command").addEventListener("keydown", e => { if (e.key === "Enter") sendCommand(); });
$("speakBtn").addEventListener("click", () => lastAnswer ? speak(lastAnswer) : setTranscript("Ask a question first."));
$("stopSpeakBtn").addEventListener("click", () => window.speechSynthesis?.cancel());

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
function maybeSpeakAnswer(text) {
  if (voiceCommandInProgress) { voiceCommandInProgress = false; speak(text); }
}
function startWakeRecognition() {
  if (!recognition || !wakeEnabled || window.speechSynthesis?.speaking) return;
  try {
    recognition.lang = (window.SM_LANGUAGES[langSelect.value] || window.SM_LANGUAGES.en).stt;
    recognition.start();
  } catch (_) { /* Browser may still be transitioning between recognition sessions. */ }
}
if (SpeechRecognition) {
  recognition = new SpeechRecognition(); recognition.continuous = true; recognition.interimResults = false;
  recognition.onstart = () => { $("micBtn").textContent = "🟢 Hey Jarvis enabled · click to stop"; $("voiceVisual").classList.add("active"); setStatus(awaitingCommand ? "waiting for command" : "wake word listening"); };
  recognition.onend = () => {
    $("voiceVisual").classList.remove("active");
    if (wakeEnabled && !window.speechSynthesis?.speaking) { setTimeout(startWakeRecognition, 350); }
    else if (!wakeEnabled) { $("micBtn").textContent = "🎙 Enable Hey Jarvis"; setStatus("ready"); }
  };
  recognition.onerror = e => {
    if (e.error === "not-allowed" || e.error === "service-not-allowed") {
      wakeEnabled = false; setTranscript("Microphone permission was denied. Allow microphone access in your browser site settings, then enable Hey Jarvis again.");
    } else if (e.error !== "no-speech" && e.error !== "aborted") setTranscript(`Speech recognition issue: ${e.error}. You can type a command instead.`);
  };
  recognition.onresult = e => {
    for (let i=e.resultIndex; i<e.results.length; i++) {
      if (!e.results[i].isFinal) continue;
      const heard = e.results[i][0].transcript.trim();
      const wakeMatch = heard.match(/\bhey\s+jarvis\b[,.!?;:]?\s*(.*)/i);
      if (!awaitingCommand) {
        if (!wakeMatch) continue;
        const command = (wakeMatch[1] || "").trim();
        awaitingCommand = !command;
        try { recognition.stop(); } catch (_) {}
        if (command) { awaitingCommand = false; voiceCommandInProgress = true; sendCommand(command); }
        else { speak("Yes? I'm listening."); }
      } else {
        awaitingCommand = false;
        try { recognition.stop(); } catch (_) {}
        voiceCommandInProgress = true;
        sendCommand(heard);
      }
    }
  };
} else {
  $("micBtn").disabled = true; $("micBtn").textContent = "Speech needs Chrome/Edge";
}
$("micBtn").addEventListener("click", () => {
  if (!recognition) return;
  if (wakeEnabled) {
    wakeEnabled = false; awaitingCommand = false;
    try { recognition.stop(); } catch (_) {}
    window.speechSynthesis?.cancel();
    $("micBtn").textContent = "🎙 Enable Hey Jarvis";
    setStatus("ready"); setTranscript("Hey Jarvis listening is off.");
  } else {
    wakeEnabled = true;
    setTranscript('Allow microphone access if prompted. Then say “Hey Jarvis” followed by your command.');
    startWakeRecognition();
  }
});

// Camera preview is mirrored locally; no video is sent to the server.
$("cameraBtn").addEventListener("click", async () => {
  if (!navigator.mediaDevices?.getUserMedia) {
    $("cameraStatus").textContent = "Camera access needs a supported browser and a secure/local origin."; return;
  }
  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({video:{facingMode:"user"}, audio:false});
    const video = $("mirrorVideo"); video.srcObject = cameraStream; await video.play(); video.classList.add("ready");
    $("mirrorPlaceholder").style.display = "none"; $("cameraBtn").disabled = true; $("cameraOffBtn").disabled = false;
    $("cameraStatus").textContent = "Mirror camera is on. Video remains in this browser.";
  } catch (e) { $("cameraStatus").textContent = `Camera unavailable: ${e.message || "permission denied"}. Check browser camera permissions.`; }
});
$("cameraOffBtn").addEventListener("click", () => {
  if (cameraStream) cameraStream.getTracks().forEach(track => track.stop());
  cameraStream = null; const video = $("mirrorVideo"); video.srcObject = null; video.classList.remove("ready");
  $("mirrorPlaceholder").style.display = "flex"; $("cameraBtn").disabled = false; $("cameraOffBtn").disabled = true;
  $("cameraStatus").textContent = "Camera is off.";
});

$("refreshNews").addEventListener("click", loadNews);
$("analyzeBtn").addEventListener("click", async () => {
  const file = $("outfitImage").files[0];
  if (!file) { $("outfitResult").textContent = "Choose an image first."; return; }
  const fd = new FormData(); fd.append("image", file); fd.append("language", langSelect.value);
  $("analyzeBtn").disabled = true; $("outfitResult").textContent = "Analyzing visible clothing and colors…";
  try {
    const r = await fetch("/api/analyze-outfit", {method:"POST", body:fd}); const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Analysis failed");
    $("outfitResult").textContent = data.answer;
  } catch(e) { $("outfitResult").textContent = e.message; }
  finally { $("analyzeBtn").disabled = false; }
});
$("hairBtn").addEventListener("click", async () => {
  $("hairResult").textContent = "Preparing prompt…";
  try {
    const r = await fetch("/api/hairstyle", {method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({style:$("hairStyle").value})});
    const data = await r.json();
    $("hairResult").textContent = `${data.prompt}\n\n${data.message}`;
  } catch(e) { $("hairResult").textContent = e.message; }
});
$("musicFile").addEventListener("change", e => {
  const file = e.target.files[0]; if (!file) return;
  if (currentObjectUrl) URL.revokeObjectURL(currentObjectUrl);
  currentObjectUrl = URL.createObjectURL(file); $("audioPlayer").src = currentObjectUrl;
});
$("playMusic").addEventListener("click", () => $("audioPlayer").play().catch(()=>setTranscript("Choose an audio file first.")));
$("pauseMusic").addEventListener("click", () => $("audioPlayer").pause());
loadWeather(); loadNews();
// Refresh live information periodically while the dashboard is open.
setInterval(loadWeather, 10 * 60 * 1000);
setInterval(loadNews, 15 * 60 * 1000);
