import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Activity, AlertTriangle, ArrowRight, Beaker, Check, ChevronRight, CircleHelp, ClipboardCheck, FileText, FlaskConical, FolderOpen, GitBranch, LoaderCircle, Save, ShieldCheck, Sparkles, Upload, X } from 'lucide-react';
import { setField, setIncident, setSourceText, setAnalysis, setCapaActions, updateCapa, updateCauseStatus, setAiMode, setActiveId, setBusy, setError, setSaved, resetDraft, loadSaved } from './store';

const API = 'http://127.0.0.1:8000';
const sample = `Deviation report: During review of fictional API batch API-26041, the reported impurity result was 0.28%, against an approved acceptance limit of NMT 0.20%. The batch is on quality hold pending investigation. The source narrative does not include the executed batch record, process temperature/time trends, raw-material results, purification records, chromatograms, or system suitability results. No root cause has been established.`;
const fields = [
  ['title','Investigation title'], ['product_name','Product / API'], ['batch_number','Batch number'], ['process_stage','Process stage'],
  ['deviation_description','Deviation description'], ['observed_result','Observed result'], ['acceptance_limit','Acceptance limit'],
  ['immediate_actions','Immediate actions / containment'], ['impact_assessment','Initial impact assessment']
];
async function request(path, options={}) {
  const res = await fetch(`${API}${path}`, options);
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.detail || `Request failed (${res.status})`);
  return data;
}
function App() {
  const dispatch = useDispatch();
  const rca = useSelector(s=>s.rca);
  const [tab, setTab] = useState('incident');
  const [sourceMode, setSourceMode] = useState('text');
  const [method, setMethod] = useState('5 Whys');
  const [health, setHealth] = useState(null);
  const [showEvidence, setShowEvidence] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(()=>{ request('/api/health').then(setHealth).catch(()=>setHealth({status:'offline'})); refreshSaved(); },[]);
  async function refreshSaved() {
    try { dispatch(setSaved(await request('/api/rca/investigations'))); } catch {}
  }
  function error(e) { dispatch(setError(e.message || String(e))); }
  async function analyze(textOverride) {
    dispatch(setError('')); dispatch(setBusy(true));
    try {
      let data;
      if (textOverride instanceof File) {
        const fd = new FormData(); fd.append('file', textOverride);
        data = await request('/api/rca/analyze', {method:'POST', body:fd});
      } else {
        const text = textOverride ?? rca.sourceText;
        data = await request('/api/rca/analyze', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({text})});
      }
      dispatch(setIncident(data.incident || {})); dispatch(setAnalysis(data.analysis || null));
      dispatch(setCapaActions(data.capa_actions || [])); dispatch(setSourceText(data.source_text || (typeof textOverride==='string'?textOverride:rca.sourceText)));
      dispatch(setAiMode(data.ai_mode || '')); setTab('incident');
    } catch(e) { error(e); } finally { dispatch(setBusy(false)); }
  }
  async function runInvestigation() {
    dispatch(setError('')); dispatch(setBusy(true));
    try {
      const data = await request('/api/rca/investigate', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({incident:rca.incident,source_text:rca.sourceText,method})});
      dispatch(setAnalysis(data.analysis)); dispatch(setCapaActions(data.capa_actions || [])); dispatch(setAiMode(data.ai_mode || '')); setTab('analysis');
    } catch(e) { error(e); } finally { dispatch(setBusy(false)); }
  }
  async function save() {
    dispatch(setError('')); setSaving(true);
    try {
      const body = {investigation_code:rca.incident.batch_number && rca.incident.batch_number!=='Not stated' ? `RCA-${rca.incident.batch_number}` : 'RCA-DRAFT',title:rca.incident.title || 'Untitled investigation',status:rca.analysis ? 'Under Review' : 'Draft',incident:rca.incident,analysis:rca.analysis || {},capa_actions:rca.capaActions,source_text:rca.sourceText};
      let item;
      if (rca.activeId) item = await request(`/api/rca/investigations/${rca.activeId}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:body.title,status:body.status,incident:body.incident,analysis:body.analysis,capa_actions:body.capa_actions,source_text:body.source_text})});
      else item = await request('/api/rca/investigations',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
      dispatch(setActiveId(item.id)); await refreshSaved();
    } catch(e) { error(e); } finally { setSaving(false); }
  }
  function loadSample() { dispatch(setSourceText(sample)); setSourceMode('text'); dispatch(setError('')); }
  const change = (key,value)=>dispatch(setField({key,value}));
  const status = health?.status==='ok' ? 'API connected' : 'API offline';
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><FlaskConical size={21}/></div><div><strong>AIVOA</strong><small>QUALITY INTELLIGENCE</small></div></div>
      <div className="workspace-label">WORKSPACE</div>
      <button className="nav-item active"><GitBranch size={17}/> Root Cause Analysis <span className="nav-dot"/></button>
      <button className="nav-item" onClick={()=>setTab('saved')}><FolderOpen size={17}/> Investigations <span className="nav-count">{rca.saved.length}</span></button>
      <div className="sidebar-bottom">
        <div className="status-card"><span className={`status-dot ${health?.status==='ok'?'good':''}`}/><div><b>{status}</b><small>{health?.ai_configured?'Groq AI configured':'Demo fallback if no key'}</small></div></div>
        <div className="privacy-note"><ShieldCheck size={15}/> Use fictional data for this demo. Review all AI suggestions.</div>
      </div>
    </aside>
    <main className="main">
      <header className="topbar"><div><div className="breadcrumb">Quality systems <ChevronRight size={14}/> <b>Root Cause Analysis</b></div><h1>Root Cause Analysis</h1><p>Investigate deviations with evidence-led AI assistance.</p></div><div className="top-actions"><span className="draft-pill"><span/> {rca.activeId?'Saved investigation':'Unsaved draft'}</span><button className="button secondary" onClick={()=>{dispatch(resetDraft());setTab('incident')}}><X size={15}/> New investigation</button><button className="button primary" onClick={save} disabled={saving}><Save size={15}/>{saving?'Saving…':'Save investigation'}</button></div></header>
      {rca.error && <div className="error-banner"><AlertTriangle size={17}/><span>{rca.error}</span><button onClick={()=>dispatch(setError(''))}><X size={15}/></button></div>}
      <section className="stats">
        <div className="stat-card"><span className="stat-icon blue"><Activity size={18}/></span><div><small>WORKFLOW STAGE</small><b>{rca.analysis?'RCA review':'Evidence intake'}</b><em>{rca.analysis?'Analysis generated':'Ready for analysis'}</em></div></div>
        <div className="stat-card"><span className="stat-icon amber"><CircleHelp size={18}/></span><div><small>EVIDENCE GAPS</small><b>{rca.analysis?.evidence_gaps?.length ?? rca.incident.missing_information?.length ?? 0}</b><em>Need investigator review</em></div></div>
        <div className="stat-card"><span className="stat-icon green"><ClipboardCheck size={18}/></span><div><small>CAPA SUGGESTIONS</small><b>{rca.capaActions.length}</b><em>Draft actions</em></div></div>
      </section>
      <div className="workflow">
        {['Evidence intake','RCA analysis','CAPA review'].map((x,i)=><div className={`workflow-step ${(i===0&&!rca.analysis)||(i===1&&rca.analysis&&tab!=='capa')||(i===2&&tab==='capa')?'current':''} ${i===0&&rca.sourceText?'done':''}`} key={x}><span>{i===0&&rca.sourceText?<Check size={14}/>:i+1}</span>{x}</div>)}
      </div>
      <div className="content-grid">
        <section className="primary-panel">
          <div className="tabs">
            <button className={tab==='incident'?'selected':''} onClick={()=>setTab('incident')}>01 Incident details</button>
            <button className={tab==='analysis'?'selected':''} onClick={()=>setTab('analysis')}>02 Root cause analysis</button>
            <button className={tab==='capa'?'selected':''} onClick={()=>setTab('capa')}>03 CAPA actions</button>
            <button className={tab==='saved'?'selected':''} onClick={()=>setTab('saved')}>Saved records</button>
          </div>
          {tab==='incident' && <div className="panel-body">
            <div className="section-heading"><div><h2>Incident information</h2><p>AI-extracted fields are editable. Verify every field against source records.</p></div><span className="ai-tag"><Sparkles size={13}/> AI-assisted</span></div>
            <div className="field-grid">
              {fields.map(([key,label])=><label className={`field ${['deviation_description','immediate_actions','impact_assessment'].includes(key)?'wide':''}`} key={key}><span>{label}</span>{['deviation_description','immediate_actions','impact_assessment'].includes(key)?<textarea rows={key==='deviation_description'?3:2} value={rca.incident[key]||''} onChange={e=>change(key,e.target.value)} placeholder="AI will populate this from the evidence…"/>:<input value={rca.incident[key]||''} onChange={e=>change(key,e.target.value)} placeholder="Not stated"/>}</label>)}
            </div>
            <div className="inline-note"><ShieldCheck size={16}/><span>Do not infer missing data. Keep unknown fields as “Not stated” until verified.</span></div>
            <div className="panel-footer"><span>{rca.aiMode||'Add source evidence to begin.'}</span><button className="button primary" disabled={rca.busy||!rca.sourceText.trim()} onClick={runInvestigation}>Continue to RCA <ArrowRight size={15}/></button></div>
          </div>}
          {tab==='analysis' && <div className="panel-body">
            <div className="section-heading"><div><h2>Root cause analysis</h2><p>Candidate explanations require evidence and investigator confirmation.</p></div><span className="ai-tag"><Sparkles size={13}/> LangGraph workflow</span></div>
            {!rca.analysis ? <div className="empty-state"><GitBranch size={28}/><h3>No analysis yet</h3><p>Analyze incident evidence first, then run the RCA workflow.</p><button className="button primary" onClick={()=>setTab('incident')}>Go to incident details</button></div> : <>
              <div className="summary-box"><small>INVESTIGATION SUMMARY</small><p>{rca.analysis.summary}</p></div>
              <div className="subheading"><h3>5 Whys</h3><span className="subtle">{rca.analysis.five_whys?.length||0} steps</span></div>
              <div className="whys">{(rca.analysis.five_whys||[]).map((w,i)=><div className="why-row" key={i}><div className="why-number">{i+1}</div><div><b>{w.why}</b><p>{w.answer}</p><small>{w.evidence_status}</small></div></div>)}</div>
              <div className="subheading"><h3>Potential root causes</h3><span className="warning-tag">Unconfirmed</span></div>
              {(rca.analysis.potential_root_causes||[]).map((c,i)=><div className="cause-card" key={i}><div className="cause-top"><div><span className="cause-label">CANDIDATE {String(i+1).padStart(2,'0')}</span><h4>{c.cause}</h4></div><span className="confidence">{c.confidence_label||'Unrated'} priority</span></div><p>{c.rationale}</p><div className="evidence-columns"><div><b>Supporting evidence</b>{(c.supporting_evidence||[]).length?c.supporting_evidence.map((x,j)=><small key={j}>• {x}</small>):<small className="muted">No supporting evidence supplied yet</small>}</div><div><b>Evidence to collect</b>{(c.evidence_needed||[]).map((x,j)=><small key={j}>• {x}</small>)}</div></div><label className="confirm-row"><input type="checkbox" checked={c.status==='Confirmed by investigator'} onChange={e=>dispatch(updateCauseStatus({index:i,confirmed:e.target.checked}))}/> I reviewed this candidate and confirm it is supported by the investigation evidence.</label><span className="warning-caption">{c.status==='Confirmed by investigator'?'Confirmed by investigator — verify documented evidence and approval record.':'Suggested — not confirmed'}</span></div>)}
              <div className="subheading"><h3>Evidence gaps</h3><span className="subtle">{rca.analysis.evidence_gaps?.length||0} open items</span></div>
              <ul className="evidence-list">{(rca.analysis.evidence_gaps||[]).map((x,i)=><li key={i}><CircleHelp size={15}/>{x}</li>)}</ul>
              <div className="subheading"><h3>Investigation checks</h3></div><ul className="evidence-list">{(rca.analysis.investigation_checks||[]).map((x,i)=><li key={i}><Check size={15}/>{x}</li>)}</ul>
              <div className="panel-footer"><span>Cause confirmation must be recorded only after a documented evidence review.</span><button className="button primary" onClick={()=>setTab('capa')}>Review CAPA <ArrowRight size={15}/></button></div>
            </>}
          </div>}
          {tab==='capa' && <div className="panel-body">
            <div className="section-heading"><div><h2>Corrective & preventive actions</h2><p>Review and edit proposed actions before saving.</p></div><span className="ai-tag"><Sparkles size={13}/> AI suggestions</span></div>
            {!rca.capaActions.length ? <div className="empty-state"><ClipboardCheck size={28}/><h3>No CAPA suggestions yet</h3><p>Run the RCA analysis to create draft action recommendations.</p><button className="button primary" onClick={()=>setTab('analysis')}>Go to RCA</button></div> : <>
              {rca.capaActions.map((a,i)=><div className="capa-card" key={i}><div className="capa-header"><span className={`action-type ${a.type==='Preventive'?'preventive':''}`}>{a.type||'Action'}</span><span className="subtle">Action {String(i+1).padStart(2,'0')}</span><button className="icon-button" title="Remove action" onClick={()=>dispatch(setCapaActions(rca.capaActions.filter((_,j)=>j!==i)))}><X size={15}/></button></div><label className="field"><span>Action description</span><textarea rows={2} value={a.action||''} onChange={e=>dispatch(updateCapa({index:i,key:'action',value:e.target.value}))}/></label><label className="field"><span>Rationale</span><textarea rows={2} value={a.rationale||''} onChange={e=>dispatch(updateCapa({index:i,key:'rationale',value:e.target.value}))}/></label><div className="field-grid three"><label className="field"><span>Owner / function</span><input value={a.owner||''} onChange={e=>dispatch(updateCapa({index:i,key:'owner',value:e.target.value}))}/></label><label className="field"><span>Due date</span><input type="date" value={a.due_date||''} onChange={e=>dispatch(updateCapa({index:i,key:'due_date',value:e.target.value}))}/></label><label className="field"><span>Status</span><select value={a.status||'Proposed'} onChange={e=>dispatch(updateCapa({index:i,key:'status',value:e.target.value}))}><option>Proposed</option><option>In progress</option><option>Completed</option><option>Verified</option></select></label></div><label className="field"><span>Effectiveness check</span><input value={a.effectiveness_check||''} onChange={e=>dispatch(updateCapa({index:i,key:'effectiveness_check',value:e.target.value}))}/></label></div>)}
              <button className="button secondary" onClick={()=>dispatch(setCapaActions([...rca.capaActions,{type:'Preventive',action:'',rationale:'',owner:'',due_date:'',effectiveness_check:'',status:'Proposed'}]))}>+ Add action</button>
              <div className="inline-note"><AlertTriangle size={16}/><span>CAPAs must address a verified cause, have an accountable owner and due date, and include a defined effectiveness check.</span></div>
              <div className="panel-footer"><span>Changes are not persisted until saved.</span><button className="button primary" onClick={save} disabled={saving}><Save size={15}/>{saving?'Saving…':'Save investigation'}</button></div>
            </>}
          </div>}
          {tab==='saved' && <div className="panel-body"><div className="section-heading"><div><h2>Saved investigations</h2><p>Reload a record from MySQL and continue editing.</p></div><button className="button secondary" onClick={refreshSaved}>Refresh</button></div>{!rca.saved.length?<div className="empty-state"><FolderOpen size={28}/><h3>No saved investigations</h3><p>Save your first draft to see it here.</p></div>:<div className="saved-list">{rca.saved.map(x=><button className="saved-item" key={x.id} onClick={async()=>{try{const full=await request(`/api/rca/investigations/${x.id}`);dispatch(loadSaved(full));setTab('incident')}catch(e){error(e)}}}><div className="saved-icon"><FileText size={18}/></div><div className="saved-copy"><b>{x.title}</b><small>{x.investigation_code} · {x.status}</small></div><ChevronRight size={16}/></button>)}</div>}</div>}
        </section>
        <aside className="assistant-panel">
          <div className="assistant-head"><div className="assistant-icon"><Sparkles size={18}/></div><div><h2>AI investigation assistant</h2><p>Evidence in. Structured insights out.</p></div><span className="live-dot"/></div>
          <div className="assistant-content">
            <div className="ai-intro"><div className="ai-avatar"><Sparkles size={17}/></div><div><b>Let's investigate this incident</b><p>Provide source evidence. I'll extract facts, identify gaps, and suggest an evidence-led investigation. You remain in control.</p></div></div>
            <div className="source-tabs"><button className={sourceMode==='text'?'on':''} onClick={()=>setSourceMode('text')}><FileText size={14}/> Text / email</button><button className={sourceMode==='pdf'?'on':''} onClick={()=>setSourceMode('pdf')}><Upload size={14}/> PDF upload</button></div>
            {sourceMode==='text'?<label className="source-area"><span>INCIDENT SOURCE</span><textarea value={rca.sourceText} onChange={e=>dispatch(setSourceText(e.target.value))} placeholder="Paste deviation narrative, investigation notes, or incident email here…"/><small>{rca.sourceText.length.toLocaleString()} / 50,000 characters</small></label>:<div className="upload-area"><Upload size={25}/><b>Upload investigation PDF</b><p>Text-based PDFs up to 10 MB</p><label className="button secondary upload-button">Choose PDF<input type="file" accept="application/pdf,.pdf" onChange={e=>{const f=e.target.files?.[0];if(f)analyze(f);e.target.value=''}}/></label></div>}
            <button className="sample-link" onClick={loadSample}><Beaker size={14}/> Load sample incident</button>
            <div className="method-box"><label><span>INVESTIGATION METHOD</span><select value={method} onChange={e=>setMethod(e.target.value)}><option>5 Whys</option></select></label><p><GitBranch size={13}/> Structured workflow · evidence gaps · CAPA draft</p></div>
            <button className="button ai-button" disabled={rca.busy||!rca.sourceText.trim()} onClick={()=>analyze()}>{rca.busy?<><LoaderCircle size={17} className="spin"/> Processing evidence…</>:<><Sparkles size={16}/> Analyze incident with AI</>}</button>
            {rca.aiMode && <div className={`mode-message ${rca.aiMode.toLowerCase().includes('demo')?'demo':''}`}><span/> {rca.aiMode}</div>}
            <div className="assistant-checklist"><b>What happens next</b><div><Check size={14}/> Extract incident fields</div><div><Check size={14}/> Highlight missing evidence</div><div><Check size={14}/> Suggest 5 Whys and possible causes</div><div><Check size={14}/> Draft corrective and preventive actions</div></div>
          </div>
          <div className="assistant-foot"><ShieldCheck size={15}/><span>AI output is advisory. No cause is confirmed automatically.</span></div>
        </aside>
      </div>
      <footer className="footer"><span>AIVOA RCA · Challenge prototype</span><span>Not for GMP production use · Qualified review required</span></footer>
    </main>
  </div>;
}
export default App;
