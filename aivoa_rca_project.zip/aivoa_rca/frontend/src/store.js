import { configureStore, createSlice } from '@reduxjs/toolkit';

const initialState = {
  incident: {
    title: '', product_name: '', batch_number: '', process_stage: '',
    deviation_description: '', observed_result: '', acceptance_limit: '',
    immediate_actions: '', impact_assessment: '', source_facts: [], missing_information: []
  },
  sourceText: '', analysis: null, capaActions: [], aiMode: '', activeId: null,
  busy: false, error: '', saved: []
};
const slice = createSlice({
  name: 'rca', initialState,
  reducers: {
    setField(state, action) { state.incident[action.payload.key] = action.payload.value; },
    setIncident(state, action) { state.incident = { ...state.incident, ...action.payload }; },
    setSourceText(state, action) { state.sourceText = action.payload; },
    setAnalysis(state, action) { state.analysis = action.payload; },
    setCapaActions(state, action) { state.capaActions = action.payload; },
    updateCapa(state, action) { state.capaActions[action.payload.index] = { ...state.capaActions[action.payload.index], [action.payload.key]: action.payload.value }; },
    updateCauseStatus(state, action) {
      const causes = state.analysis?.potential_root_causes || [];
      if (causes[action.payload.index]) causes[action.payload.index].status = action.payload.confirmed ? 'Confirmed by investigator' : 'Suggested — not confirmed';
    },
    setAiMode(state, action) { state.aiMode = action.payload; },
    setActiveId(state, action) { state.activeId = action.payload; },
    setBusy(state, action) { state.busy = action.payload; },
    setError(state, action) { state.error = action.payload; },
    setSaved(state, action) { state.saved = action.payload; },
    resetDraft(state) { return { ...initialState, saved: state.saved }; },
    loadSaved(state, action) {
      const x = action.payload;
      state.activeId = x.id; state.incident = x.incident || initialState.incident;
      state.sourceText = x.source_text || ''; state.analysis = x.analysis || null;
      state.capaActions = x.capa_actions || []; state.aiMode = 'Loaded saved investigation';
    }
  }
});
export const { setField, setIncident, setSourceText, setAnalysis, setCapaActions, updateCapa, updateCauseStatus, setAiMode, setActiveId, setBusy, setError, setSaved, resetDraft, loadSaved } = slice.actions;
export const store = configureStore({ reducer: { rca: slice.reducer } });