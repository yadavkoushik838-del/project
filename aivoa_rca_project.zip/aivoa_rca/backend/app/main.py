from datetime import datetime, timezone
from pathlib import Path
import fitz
from fastapi import FastAPI, Depends, File, HTTPException, UploadFile, Request
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from .config import settings
from .database import Base, engine, get_db
from .models import Investigation
from .schemas import AnalyzeTextRequest, InvestigateRequest, InvestigationSave, InvestigationPatch
from .ai_workflow import rca_graph, demo_extract, demo_capa

Base.metadata.create_all(bind=engine)
app = FastAPI(title="AIVOA RCA API", version="1.0.0", description="AI-assisted pharmaceutical API root cause investigation prototype")
app.add_middleware(CORSMiddleware, allow_origins=[settings.frontend_origin, "http://127.0.0.1:5173"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def extract_pdf(data: bytes) -> str:
    try:
        with fitz.open(stream=data, filetype="pdf") as doc:
            text = "\n".join(page.get_text("text") for page in doc)
        if not text.strip():
            raise HTTPException(status_code=422, detail="No selectable text found in PDF. Scanned PDFs need OCR, which this starter does not include.")
        return text[:50000]
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not read PDF: {exc}")

@app.get("/api/health")
def health():
    return {"status":"ok", "service":"aivoa-rca", "ai_configured":bool(settings.groq_api_key), "model":settings.groq_model}

@app.post("/api/rca/analyze")
async def analyze(request: Request, db: Session = Depends(get_db)):
    content_type = request.headers.get("content-type", "")
    text = ""
    if "multipart/form-data" in content_type:
        form = await request.form()
        uploaded = form.get("file")
        text = str(form.get("text", "") or "")
        if uploaded is not None and hasattr(uploaded, "read"):
            filename = getattr(uploaded, "filename", "") or ""
            if getattr(uploaded, "content_type", "") != "application/pdf" and not filename.lower().endswith(".pdf"):
                raise HTTPException(status_code=415, detail="Please upload a PDF file.")
            content = await uploaded.read()
            if len(content) > 10 * 1024 * 1024:
                raise HTTPException(status_code=413, detail="PDF is larger than the 10 MB limit.")
            text = extract_pdf(content)
    elif "application/json" in content_type:
        body = await request.json()
        text = str(body.get("text", "") or "")
    else:
        text = request.query_params.get("text", "")
    if not text or len(text.strip()) < 10:
        raise HTTPException(status_code=422, detail="Paste at least 10 characters or upload a PDF.")
    result = rca_graph.invoke({"source_text":text, "method":"5 Whys"})
    return {"incident":result.get("incident", demo_extract(text)), "analysis":result.get("analysis", {}), "capa_actions":result.get("capa_actions", demo_capa({})), "source_text":text, "ai_mode":result.get("mode","demo")}

@app.post("/api/rca/investigate")
def investigate(payload: InvestigateRequest):
    source = payload.source_text or json_safe(payload.incident)
    # Re-run analysis on the reviewed/edited incident values; do not re-extract and overwrite them.
    from .ai_workflow import analysis_node
    state = {"source_text":source, "incident":payload.incident, "method":payload.method, "mode":"live" if settings.groq_api_key else "demo"}
    result = analysis_node(state)
    return {"analysis":result["analysis"], "capa_actions":result["capa_actions"], "ai_mode":result.get("mode","demo")}

def json_safe(value):
    import json
    return json.dumps(value, ensure_ascii=False)

@app.post("/api/rca/investigations", status_code=201)
def save_investigation(payload: InvestigationSave, db: Session = Depends(get_db)):
    item = Investigation(
        investigation_code=payload.investigation_code or f"RCA-{datetime.now().strftime('%y%m%d%H%M%S')}",
        title=payload.title, status=payload.status, incident=payload.incident,
        analysis=payload.analysis, capa_actions=payload.capa_actions, source_text=payload.source_text
    )
    db.add(item); db.commit(); db.refresh(item)
    return serialize(item)

@app.get("/api/rca/investigations")
def list_investigations(db: Session = Depends(get_db)):
    return [serialize(x, include_source=False) for x in db.query(Investigation).order_by(Investigation.updated_at.desc()).limit(100).all()]

@app.get("/api/rca/investigations/{investigation_id}")
def get_investigation(investigation_id: int, db: Session = Depends(get_db)):
    item = db.get(Investigation, investigation_id)
    if not item: raise HTTPException(status_code=404, detail="Investigation not found.")
    return serialize(item)

@app.patch("/api/rca/investigations/{investigation_id}")
def patch_investigation(investigation_id: int, payload: InvestigationPatch, db: Session = Depends(get_db)):
    item = db.get(Investigation, investigation_id)
    if not item: raise HTTPException(status_code=404, detail="Investigation not found.")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(item, key, value)
    item.updated_at = datetime.now(timezone.utc)
    db.commit(); db.refresh(item)
    return serialize(item)

def serialize(item: Investigation, include_source=True):
    data = {
        "id":item.id, "investigation_code":item.investigation_code, "title":item.title,
        "status":item.status, "incident":item.incident, "analysis":item.analysis,
        "capa_actions":item.capa_actions,
        "created_at":item.created_at.isoformat() if item.created_at else None,
        "updated_at":item.updated_at.isoformat() if item.updated_at else None
    }
    if include_source: data["source_text"] = item.source_text
    return data
