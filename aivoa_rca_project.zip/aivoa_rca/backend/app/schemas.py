from pydantic import BaseModel, Field
from typing import Any

class AnalyzeTextRequest(BaseModel):
    text: str = Field(min_length=10, max_length=50000)

class InvestigateRequest(BaseModel):
    incident: dict[str, Any]
    source_text: str = ""
    method: str = "5 Whys"

class InvestigationSave(BaseModel):
    investigation_code: str = "RCA-DRAFT"
    title: str = "Untitled investigation"
    status: str = "Draft"
    incident: dict[str, Any]
    analysis: dict[str, Any] = {}
    capa_actions: list[dict[str, Any]] = []
    source_text: str = ""

class InvestigationPatch(BaseModel):
    title: str | None = None
    status: str | None = None
    incident: dict[str, Any] | None = None
    analysis: dict[str, Any] | None = None
    capa_actions: list[dict[str, Any]] | None = None
    source_text: str | None = None
