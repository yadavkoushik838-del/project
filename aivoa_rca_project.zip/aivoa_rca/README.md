# AIVOA AI-powered Root Cause Analysis (RCA)

A local-development starter for the AIVOA pharmaceutical API manufacturing challenge. It includes React + Redux Toolkit, FastAPI, LangGraph, Groq, SQLAlchemy and MySQL.

> Educational prototype only. Use fictional data. AI-generated causes and CAPAs are suggestions, not GMP decisions. A qualified person must review and confirm findings. Do not upload confidential manufacturing or patient data to an external model without authorization.

## 1. Prerequisites
- Python 3.11+
- Node.js 20+
- MySQL 8+
- VS Code

## 2. Create MySQL database
Open MySQL Workbench or a MySQL terminal and run:

```sql
CREATE DATABASE aivoa_rca CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'rca_user'@'localhost' IDENTIFIED BY 'change_this_password';
GRANT ALL PRIVILEGES ON aivoa_rca.* TO 'rca_user'@'localhost';
FLUSH PRIVILEGES;
```

Use a strong local password and put it only in `backend/.env`.

## 3. Configure Groq
1. Visit https://console.groq.com/ and sign in.
2. Open the API keys section and create a key.
3. Copy it once into `backend/.env` as `GROQ_API_KEY=...`.
4. Never paste the key into frontend code, commit it, or share it in screenshots.

The default model is `openai/gpt-oss-20b`. Models change over time; if Groq reports that it is unavailable for your account, choose a currently supported chat model in Groq Console and update `GROQ_MODEL` in `.env`. The app has a clearly labelled demo fallback if no key is configured, so the UI can still be tested, but live AI requires a valid key.

## 4. Start backend (Windows PowerShell)
```powershell
cd backend
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
# Edit .env with your MySQL password and Groq key
uvicorn app.main:app --reload
```
Backend: http://127.0.0.1:8000  
API docs: http://127.0.0.1:8000/docs

If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` in that terminal, then activate again. Or use Command Prompt: `.venv\\Scripts\\activate.bat`.

## 5. Start frontend in a second terminal
```powershell
cd frontend
npm install
npm run dev
```
Open the URL printed by Vite (usually http://localhost:5173).

## 6. Test the full flow
1. Click **Load sample incident** to populate a fictional impurity OOS report.
2. Click **Analyze incident with AI**. This extracts incident fields and proposes missing evidence.
3. Review/edit all populated fields.
4. Click **Run RCA + CAPA** for a 5 Whys chain, candidate causes and CAPA suggestions.
5. Edit the results, select a candidate cause, and explicitly mark it confirmed only after human review.
6. Click **Save investigation** and confirm the item appears in Saved investigations. Refresh/reopen to test persistence.

Without MySQL, set `DATABASE_URL` to a SQLite URL only for a local UI/demo test (e.g. `sqlite:///./aivoa_rca.db`). MySQL is the intended database for this challenge.

## 7. Useful endpoints
- `GET /api/health`
- `POST /api/rca/analyze` (text or PDF upload)
- `POST /api/rca/investigate`
- `POST /api/rca/investigations`
- `GET /api/rca/investigations`
- `GET /api/rca/investigations/{id}`
- `PATCH /api/rca/investigations/{id}`

## 8. Submission videos
**Product demo (5–8 min):** show sample evidence → AI extraction → editable form → RCA/5 Whys → evidence gaps → CAPA review → save and reload.

**Technical walkthrough (5–10 min):** explain `frontend/src/App.jsx`, Redux state, `backend/app/main.py`, `backend/app/ai_workflow.py`, SQLAlchemy models, environment variables, and API calls.

## 9. Before submission
- Replace the sample with a fictional scenario you understand.
- Test with and without a Groq key, and verify the database saves records.
- Never represent this prototype as validated GxP software. Production use would require security, access control, audit trails, validation, retention controls, change management, and qualified quality approval.
- Keep project and videos private as requested by the challenge.
